﻿using CakeCompany.Models;
using CakeCompany.Models.Transport;
using CakeCompany.Provider;
using CakeCompany.Provider.Interface;
using CakeCompany.Utility;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CakeCompany.UnitTest
{
    [TestClass]
    public class ShipmentProviderTests
    {
        private Mock<IOrderProvider> mockOrderProvider;
        private Mock<IPaymentProvider> mockPaymentProvider;
        private Mock<ICakeProvider> mockCakeProvider;
        private Mock<ITransportProvider> mockTransportProvider;
        private Mock<ICustomLogger<ShipmentProvider>> mockLogger;
        private ShipmentProvider shipmentProvider;

        [TestInitialize]
        public void TestInitialize()
        {
            this.mockOrderProvider = new Mock<IOrderProvider>(MockBehavior.Strict);
            this.mockPaymentProvider = new Mock<IPaymentProvider>(MockBehavior.Strict);
            this.mockCakeProvider = new Mock<ICakeProvider>(MockBehavior.Strict);
            this.mockTransportProvider = new Mock<ITransportProvider>(MockBehavior.Strict);
            this.mockLogger = new Mock<ICustomLogger<ShipmentProvider>>(MockBehavior.Strict);
            this.shipmentProvider = new ShipmentProvider(this.mockCakeProvider.Object,
                this.mockOrderProvider.Object,
                this.mockPaymentProvider.Object,
                this.mockTransportProvider.Object,
                this.mockLogger.Object);
        }

        [TestMethod]
        public void GetShipment_ShouldReturnFalse_WhenNoOrderExists()
        {
            //arrange
            this.mockOrderProvider.Setup(t => t.GetLatestOrders()).Returns(new List<Order>().ToArray());
            this.mockLogger.Setup(t => t.LogInformation(It.IsAny<string>()));

            // Act
            var result = this.shipmentProvider.GetShipment();

            // Assert
            Assert.AreEqual("No Order found", result);
        }

        [TestMethod]
        public void GetShipment_ShouldReturnGenericMessage_WhenExceptionOccurs()
        {
            // arrange
            var expectedResult = "Sorry Error occured";
            var payment = new PaymentIn() { HasCreditLimit = false, IsSuccessful = true };
            var products = new Product[] { new Product(Guid.NewGuid(), Cake.RedVelvet, 2, 7) };
            var orders = new Order[] {
            new Order("ChocolateBox", DateTime.Now.AddHours(4), 10, new OrderProduct[] { new OrderProduct(Cake.Chocolate, 60), new OrderProduct(Cake.RedVelvet, 80) }),
            new Order("RedVelvetBox", DateTime.Now.AddMinutes(15), 20, new OrderProduct[] { new OrderProduct(Cake.RedVelvet, 2) })};

            this.mockOrderProvider.Setup(t => t.GetLatestOrders()).Returns(orders);
            this.mockLogger.Setup(t => t.LogError(It.IsAny<Exception>(), It.IsAny<string>()));
            this.mockLogger.Setup(t => t.LogInformation(It.IsAny<string>()));
            this.mockCakeProvider.Setup(t => t.CheckEstimatedTimeValid(orders[0])).Returns(true);
            this.mockCakeProvider.Setup(t => t.CheckEstimatedTimeValid(orders[1])).Returns(false);
            this.mockPaymentProvider.Setup(t => t.Process(orders[0])).Returns(payment);
            this.mockTransportProvider.Setup(t => t.CheckForAvailability(It.IsAny<int>())).Returns(new Van());

            // Act
            var result = this.shipmentProvider.GetShipment();

            // Assert
            Assert.IsNotNull(result);
            Assert.AreEqual(expectedResult, result);
        }

        [TestMethod]
        public void GetShipment_ShouldReturnValidInfo_WhenNoProductExists()
        {
            // arrange
            var expectedResult = "No Products available to Deliver";
            var payment = new PaymentIn() { HasCreditLimit = false, IsSuccessful = false };
            var products = new Product[] { new Product(Guid.NewGuid(), Cake.RedVelvet, 2, 7) };
            var orders = new Order[] {
            new Order("invalidChocolateBox", DateTime.Now.AddHours(4), 10, new OrderProduct[] { new OrderProduct(Cake.Chocolate, 60), new OrderProduct(Cake.RedVelvet, 80) }),
            new Order("RedVelvetBox", DateTime.Now.AddMinutes(15), 20, new OrderProduct[] { new OrderProduct(Cake.RedVelvet, 2) })};

            this.mockOrderProvider.Setup(t => t.GetLatestOrders()).Returns(orders);
            this.mockLogger.Setup(t => t.LogInformation(It.IsAny<string>()));
            this.mockCakeProvider.Setup(t => t.CheckEstimatedTimeValid(orders[0])).Returns(true);
            this.mockCakeProvider.Setup(t => t.CheckEstimatedTimeValid(orders[1])).Returns(false);
            this.mockPaymentProvider.Setup(t => t.Process(orders[0])).Returns(payment);
            this.mockTransportProvider.Setup(t => t.CheckForAvailability(It.IsAny<int>())).Returns(new Van());

            // Act
            var result = this.shipmentProvider.GetShipment();

            // Assert
            Assert.IsNotNull(result);
            Assert.AreEqual(expectedResult, result);
        }

        [TestMethod]
        public void GetShipment_ShouldReturnCancelledOrderDetails_WhenPaymentFailed()
        {
            // arrange
            var expectedResult = "/CancelledOrders: 10";
            var payment = new PaymentIn() { HasCreditLimit = false, IsSuccessful = true };
            var products = new Product[] { new Product(Guid.NewGuid(), Cake.RedVelvet, 2, 7) };
            var orders = new Order[] {
            new Order("invalidChocolateBox", DateTime.Now.AddHours(4), 10, new OrderProduct[] { new OrderProduct(Cake.Chocolate, 60), new OrderProduct(Cake.RedVelvet, 80) }),
            new Order("RedVelvetBox", DateTime.Now.AddHours(6), 20, new OrderProduct[] { new OrderProduct(Cake.RedVelvet, 2) })};

            this.mockOrderProvider.Setup(t => t.GetLatestOrders()).Returns(orders);
            this.mockLogger.Setup(t => t.LogInformation(It.IsAny<string>()));
            this.mockCakeProvider.Setup(t => t.CheckEstimatedTimeValid(orders[0])).Returns(true);
            this.mockCakeProvider.Setup(t => t.CheckEstimatedTimeValid(orders[1])).Returns(true);
            this.mockPaymentProvider.Setup(t => t.Process(orders[0])).Returns(new PaymentIn() { HasCreditLimit = false, IsSuccessful = false });
            this.mockPaymentProvider.Setup(t => t.Process(orders[1])).Returns(payment);
            this.mockCakeProvider.Setup(t => t.Bake(orders[1])).Returns(products);
            this.mockTransportProvider.Setup(t => t.CheckForAvailability(It.IsAny<int>())).Returns(new Van());

            // Act
            var result = this.shipmentProvider.GetShipment();

            // Assert
            Assert.IsNotNull(result);
            Assert.IsTrue(result.Contains(expectedResult));
        }

        [TestMethod]
        public void GetShipment_ShouldReturnCancelledOrderDetails_WhenEstimatedDeliveryTimeNotMatch()
        {
            // arrange
            var expectedResult = "/CancelledOrders: 10";
            var payment = new PaymentIn() { HasCreditLimit = false, IsSuccessful = true };
            var products = new Product[] { new Product(Guid.NewGuid(), Cake.RedVelvet, 2, 7) };
            var orders = new Order[] {
            new Order("ChocolateBox", DateTime.Now.AddMinutes(20), 10, new OrderProduct[] { new OrderProduct(Cake.Chocolate, 60), new OrderProduct(Cake.RedVelvet, 80) }),
            new Order("RedVelvetBox", DateTime.Now.AddHours(6), 20, new OrderProduct[] { new OrderProduct(Cake.RedVelvet, 2) })};

            this.mockOrderProvider.Setup(t => t.GetLatestOrders()).Returns(orders);
            this.mockLogger.Setup(t => t.LogInformation(It.IsAny<string>()));
            this.mockCakeProvider.Setup(t => t.CheckEstimatedTimeValid(orders[0])).Returns(false);
            this.mockCakeProvider.Setup(t => t.CheckEstimatedTimeValid(orders[1])).Returns(true);
            this.mockPaymentProvider.Setup(t => t.Process(orders[1])).Returns(payment);
            this.mockCakeProvider.Setup(t => t.Bake(orders[1])).Returns(products);
            this.mockTransportProvider.Setup(t => t.CheckForAvailability(It.IsAny<int>())).Returns(new Van());

            // Act
            var result = this.shipmentProvider.GetShipment();

            // Assert
            Assert.IsNotNull(result);
            Assert.IsTrue(result.Contains(expectedResult));
        }

        [TestMethod]
        public void GetShipment_ShouldReturnOrderDetails_WhenHasValidOrders()
        {
            // arrange
            var expectedResult = "Products ready for Delivery - Transport: Van /OrderDetails: 10, 20 /CancelledOrders: ";
            var payment = new PaymentIn() { HasCreditLimit = false, IsSuccessful = true };
            var products = new Product[] { new Product(Guid.NewGuid(), Cake.Chocolate, 60, 5),
                new Product(Guid.NewGuid(), Cake.RedVelvet, 80, 6) };
            var productlist2 = new Product[] { new Product(Guid.NewGuid(), Cake.RedVelvet, 2, 7) };
            var orders = new Order[] {
            new Order("ChocolateBox", DateTime.Now.AddHours(4), 10, new OrderProduct[] { new OrderProduct(Cake.Chocolate, 60), new OrderProduct(Cake.RedVelvet, 80) }),
            new Order("RedVelvetBox", DateTime.Now.AddHours(6), 20, new OrderProduct[] { new OrderProduct(Cake.RedVelvet, 2) })};

            this.mockOrderProvider.Setup(t => t.GetLatestOrders()).Returns(orders);
            this.mockLogger.Setup(t => t.LogInformation(It.IsAny<string>()));
            this.mockCakeProvider.Setup(t => t.CheckEstimatedTimeValid(orders[0])).Returns(true);
            this.mockCakeProvider.Setup(t => t.CheckEstimatedTimeValid(orders[1])).Returns(true);
            this.mockPaymentProvider.Setup(t => t.Process(It.IsAny<Order>())).Returns(payment);
            this.mockCakeProvider.Setup(t => t.Bake(orders[0])).Returns(products);
            this.mockCakeProvider.Setup(t => t.Bake(orders[1])).Returns(productlist2);
            this.mockTransportProvider.Setup(t => t.CheckForAvailability(It.IsAny<int>())).Returns(new Van());

            // Act
            var result = this.shipmentProvider.GetShipment();

            // Assert
            Assert.AreEqual(expectedResult, result);
        }
    }
}
