﻿// See https://aka.ms/new-console-template for more information

using CakeCompany.Provider;
using Microsoft.Extensions.Hosting;

namespace CakeCompany
{
    public static class Program
    {
        public static void Main(string[] args)
        {
            CreateHostBuilder(args).Start();

            var shipmentProvider = Startup.Resolve<ShipmentProvider>();
            var details = shipmentProvider.GetShipment();

            Console.WriteLine("Shipment Details... " + details);
        }

        public static IHost CreateHostBuilder(string[] args) =>
            Host.CreateDefaultBuilder(args)
                .ConfigureServices(webBuilder =>
                {
                    Startup.ConfigureServices(webBuilder);
                })
             .Start();
    }
}
