﻿using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CakeCompany.Utility
{
    internal class CustomLogger<T> : ICustomLogger<T>
    {
        private readonly ILogger<T> logger;

        public CustomLogger(ILogger<T> logger)
        {
            this.logger = logger;
        }

        public IDisposable BeginScope<TState>(TState state)
        {
            return this.logger.BeginScope(state);
        }

        public bool IsEnabled(LogLevel logLevel)
        {
            return this.logger.IsEnabled(logLevel);
        }

        public void Log<TState>(LogLevel logLevel, EventId eventId, TState state, Exception exception, Func<TState, Exception, string> formatter)
        {
            this.logger.Log(logLevel, eventId, state, exception, formatter);
        }

        public void LogError(Exception exception, string message)
        {
            this.logger.LogError(exception, message);
        }

        public void LogInformation(string message)
        {
            this.logger.LogInformation(message);
        }
    }
}
