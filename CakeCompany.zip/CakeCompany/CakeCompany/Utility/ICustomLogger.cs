﻿using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CakeCompany.Utility
{
    internal interface ICustomLogger<out TCategoryName> : ILogger
    {
        void LogError(Exception exception, string message);

        void LogInformation(string message);
    }
}
