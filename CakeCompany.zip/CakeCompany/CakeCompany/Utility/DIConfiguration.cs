﻿using CakeCompany.Provider.Interface;
using CakeCompany.Provider;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;

namespace CakeCompany.Utility
{
    internal class DIConfiguration
    {
        public static void ConfigureServices(IServiceCollection services)
        {
            if (services == null)
            {
                throw new ArgumentNullException(nameof(services));
            }

            services.AddSingleton<ShipmentProvider>();
            services.AddSingleton<ICakeProvider, CakeProvider>();
            services.AddSingleton<IOrderProvider, OrderProvider>();
            services.AddSingleton<IPaymentProvider, PaymentProvider>();
            services.AddSingleton<ITransportProvider, TransportProvider>();
            services.AddSingleton(typeof(ILogger<>), typeof(Logger<>));

            services.AddSingleton(typeof(ICustomLogger<>), typeof(CustomLogger<>));
        }
    }
}
