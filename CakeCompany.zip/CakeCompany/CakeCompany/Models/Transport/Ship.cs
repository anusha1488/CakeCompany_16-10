﻿using CakeCompany.Models.Transport.Interface;

namespace CakeCompany.Models.Transport;

internal class Ship : ITransport
{
    public bool Deliver(List<Product> products)
    {
        return true;
    }
}