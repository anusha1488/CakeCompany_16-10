﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CakeCompany.Models
{
    internal class OrderProduct
    {
        public Cake Cake { get; set; }
        public int Quantity { get; set; }
        public OrderProduct(Cake cake, int quantity)
        {
            Cake = cake;
            Quantity = quantity;
        }
    }
}
