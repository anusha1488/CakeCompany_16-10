﻿namespace CakeCompany.Models;

internal enum Cake
{
    Chocolate,
    Vanilla,
    RedVelvet
}