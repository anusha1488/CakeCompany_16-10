﻿namespace CakeCompany.Models.Cakes;

internal record Vanilla(string CakeName);
