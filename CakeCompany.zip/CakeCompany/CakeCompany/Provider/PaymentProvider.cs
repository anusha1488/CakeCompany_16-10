﻿using CakeCompany.Models;
using CakeCompany.Provider.Interface;

namespace CakeCompany.Provider;

internal class PaymentProvider : IPaymentProvider
{
    public PaymentIn Process(Order order)
    {
        //TODO: Need to check payment gateway, temporarily validating using client name
        var paymentIn = new PaymentIn();
        paymentIn.HasCreditLimit = order.ClientName != null && order.ClientName.ToLower().Contains("important");
        paymentIn.IsSuccessful = order.ClientName != null && !order.ClientName.ToLower().Contains("invalid");
        return paymentIn;
    }
}