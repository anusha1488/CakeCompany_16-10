﻿using System.Reflection.Metadata.Ecma335;
using CakeCompany.Models;
using CakeCompany.Provider.Interface;

namespace CakeCompany.Provider;

internal class OrderProvider : IOrderProvider
{
    // Update this to handle multiple product selection per client
    public virtual Order[] GetLatestOrders()
    {
        return new Order[]
        {
            new("CakeBox", DateTime.Now.AddHours(3), 101, new OrderProduct[] { new OrderProduct(Cake.RedVelvet, 120), new OrderProduct(Cake.Vanilla, 50) }),
            new("ShortCakeBox", DateTime.Now, 99, new OrderProduct[] { new OrderProduct(Cake.Chocolate, 40), new OrderProduct(Cake.Vanilla, 50) }),
            new("invalidCakeBox", DateTime.Now.AddHours(5), 23, new OrderProduct[] { new OrderProduct(Cake.Chocolate, 40), new OrderProduct(Cake.Vanilla, 50) }),
            new("ImportantCakeShop", DateTime.Now.AddDays(1), 77, new OrderProduct[] { new OrderProduct(Cake.Vanilla, 30) })
        };
    }

    public void UpdateOrders(Order[] orders)
    {
    }
}


