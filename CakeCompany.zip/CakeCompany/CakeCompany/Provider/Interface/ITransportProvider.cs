﻿using CakeCompany.Models.Transport.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CakeCompany.Provider.Interface
{
    internal interface ITransportProvider
    {
        ITransport CheckForAvailability(int totalProductsQuantity);
    }
}
