﻿using CakeCompany.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CakeCompany.Provider.Interface
{
    internal interface ICakeProvider
    {
        bool CheckEstimatedTimeValid(Order order);

        Product[] Bake(Order order);
    }
}
