﻿using CakeCompany.Models;
using CakeCompany.Models.Transport.Interface;
using CakeCompany.Models.Transport;
using CakeCompany.Provider.Interface;

namespace CakeCompany.Provider;

internal class TransportProvider : ITransportProvider
{
    /// <summary>
    /// To get transpoty based on products count
    /// </summary>
    /// <param name="products"></param>
    /// <returns></returns>
    public ITransport CheckForAvailability(int totalProductsQuantity)
    {
        // if total products count less then 1000, return Van
        if (totalProductsQuantity < 1000)
        {
            return new Van();
        }

        // if total products count greater then 1000 and less then 5000, return Truck
        if (totalProductsQuantity > 1000 && totalProductsQuantity < 5000)
        {
            return new Truck();
        }

        // if total products count greater then 5000, return Ship
        return new Ship();
    }
}
