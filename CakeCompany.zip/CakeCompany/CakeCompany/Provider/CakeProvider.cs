﻿using CakeCompany.Models;
using CakeCompany.Provider.Interface;

namespace CakeCompany.Provider;

internal class CakeProvider : ICakeProvider
{
    public bool CheckEstimatedTimeValid(Order order)
    {
        var totalTime = DateTime.Now;
        foreach (var product in order.OrderProducts)
        {
            switch (product.Cake)
            {
                case Cake.Chocolate:
                    totalTime.Add(TimeSpan.FromMinutes(30));
                    break;
                case Cake.RedVelvet:
                    totalTime.Add(TimeSpan.FromMinutes(60));
                    break;
                default:
                    totalTime.Add(TimeSpan.FromHours(15));
                    break;
            }
        }

        return totalTime <= order.EstimatedDeliveryTime;

    }

    public Product[] Bake(Order order)
    {
        var productList = order.OrderProducts.Select(t =>
           new Product(
               Guid.NewGuid(),
               t.Cake,
               t.Quantity,
               order.Id
           )).ToArray();

        return productList;
    }
}