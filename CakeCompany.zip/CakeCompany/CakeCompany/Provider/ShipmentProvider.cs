﻿using System.Diagnostics;
using CakeCompany.Models;
using CakeCompany.Models.Transport;
using CakeCompany.Models.Transport.Interface;
using CakeCompany.Provider.Interface;
using CakeCompany.Utility;
using Microsoft.Extensions.Logging;

namespace CakeCompany.Provider;

internal class ShipmentProvider
{
    private ICakeProvider cakeProvider;
    private IOrderProvider orderProvider;
    private IPaymentProvider paymentProvider;
    private ITransportProvider transportProvider;
    private ICustomLogger<ShipmentProvider> logger;

    public ShipmentProvider(ICakeProvider cakeProvider, IOrderProvider orderProvider, IPaymentProvider paymentProvider, ITransportProvider transportProvider, ICustomLogger<ShipmentProvider> logger)
    {
        this.cakeProvider = cakeProvider;
        this.orderProvider = orderProvider;
        this.paymentProvider = paymentProvider;
        this.transportProvider = transportProvider;
        this.logger = logger;
    }

    public string GetShipment()
    {
        try
        {
            // to get latest orders list
            var orders = this.orderProvider.GetLatestOrders();
            if (orders == null || !orders.Any())
            {
                this.logger.LogInformation("No Order found on " + DateTime.UtcNow);
                return "No Order found";
            }

            var cancelledOrders = new List<Order>();
            var products = new Dictionary<int, List<Product>>();

            foreach (var order in orders)
            {
                // to cancel orders, if estimated time exceeds
                var isEstimatedDeliveryValid = this.cakeProvider.CheckEstimatedTimeValid(order);
                if (!isEstimatedDeliveryValid)
                {
                    cancelledOrders.Add(order);
                    this.logger.LogInformation("Order Cancelled due to Estimated Delivery Time - OrderId:" + order.Id);
                    continue;
                }

                // to cancel order, if payment failed
                if (!this.paymentProvider.Process(order).IsSuccessful)
                {
                    cancelledOrders.Add(order);
                    this.logger.LogInformation("Order Cancelled due to unsucessfull payment - OrderId:" + order.Id);
                    continue;
                }

                var product = cakeProvider.Bake(order);
                products.Add(order.Id, product.ToList());
                this.logger.LogInformation("Products available for Delivery - OrderId:" + order.Id);
            }

            if (products.Any())
            {
                var totalProducts = products.SelectMany(t => t.Value.Select(x => x)).ToList();
                var transport = this.HandleDelivery(totalProducts);
                if (transport != null)
                {
                    var type = transport.GetType().Name;
                    var orderProcessed = string.Join(", ", products.Select(t => t.Key));
                    var cancelledOrderId = string.Join(", ", cancelledOrders.Select(t => t.Id));
                    var details = $"Products ready for Delivery - Transport: {type} /OrderDetails: {orderProcessed} /CancelledOrders: {cancelledOrderId}";
                    return details;
                }
            }
            else
            {
                return "No Products available to Deliver";
            }


            return "No details found";
        }
        catch (Exception exception)
        {
            this.logger.LogError(exception, exception.Message);
            return "Sorry Error occured";
        }
    }

    /// <summary>
    /// To get the transport based on product quantity
    /// </summary>
    /// <param name="productCount"></param>
    /// <returns></returns>
    private ITransport HandleDelivery(List<Product> products)
    {
        try
        {
            var productQuantity = products.Sum(t => t.Quantity);
            var transport = this.transportProvider.CheckForAvailability(productQuantity);

            if (transport is Van)
            {
                transport.Deliver(products);
            }

            if (transport is Truck)
            {
                transport.Deliver(products);
            }

            if (transport is Ship)
            {
                transport.Deliver(products);
            }

            return transport;
        }
        catch (Exception ex)
        {
            this.logger.LogError(ex.Message, string.Join(", ", products.Select(t => t.OrderId)));
            return null;
        }
    }
}
