﻿using CakeCompany.Utility;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CakeCompany
{
    internal class Startup
    {
        public static IServiceProvider CurrentProvider { get; internal set; }

        public static T Resolve<T>()
        {
            return CurrentProvider.GetService<T>();
        }

        public static void ConfigureServices(IServiceCollection services)
        {
            DIConfiguration.ConfigureServices(services);
            CurrentProvider = services.BuildServiceProvider();

            services.AddLogging(t => t.AddConsole());
        }
    }
}
